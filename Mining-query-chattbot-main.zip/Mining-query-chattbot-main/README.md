# Mining-query-chattbot
Developed a Chatbot to respond to text queries pertaining to various acts ,rules ,and regulations applicable to mining industries.
![image](https://github.com/user-attachments/assets/48f9048e-b24c-4e4b-be9a-773f245379cd)
Graphical User Interface
![image](https://github.com/user-attachments/assets/74bfa97a-c5f2-43dd-aa3f-a329e9ff7022)
Related Questions panel
![image](https://github.com/user-attachments/assets/fef8d17c-7d8e-4359-97ae-9bf913b7a392)
Username Window
